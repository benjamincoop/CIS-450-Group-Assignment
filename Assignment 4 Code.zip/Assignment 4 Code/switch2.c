void f(int i) 
{
  int x;

  switch (i+2) {
   case 1: x = 2; break;
   case 2: x = 7; break;
   case 3: x = 5; break;
   case 4: x = 12; break;
   case 5: x = 23; break;
   default: x = -1;
  }
}

