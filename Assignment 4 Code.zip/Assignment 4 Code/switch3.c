void f(int i) {
  int x = 4;

  switch (x) {
   case 1: x= 3; break;
   case 2: x = 4; break;
   case 3: x = 5; break;
   case 5: x = 6; break;
   case 6: x = 7; break;
   case 8: x = 8; break;
   case 9: x = 9; break;
   case 10: x = 10; break;
   case 12: x = 11; break;
   case 13: x = 12; break;
   case 15: x = 13; break;
   case 16: x = 14; break;
   case 17: x = 14; break;
   case 18: x = 14; break;
   case 19: x = 14; break;
   case 22: x = 14; break;
   case 23: x = 14; break;
   case 28: x = 14; break;
   case 29: x = 14; break;
   case 30: x = 14; break;
   case 31: x = 14; break;
   case 33: x = 14; break;
   default: x = -1;
  }
}
   
