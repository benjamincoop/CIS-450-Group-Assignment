void f(int i) {
  int x = 4;

  switch (i * 2) {
    case 10: x = 10; break;
    case 20: x = 15; break;
    case 40: x = 18; break;
    default: x = -1;
  }
}
   
