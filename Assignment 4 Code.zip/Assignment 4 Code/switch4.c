void f(int i) 
{
  int x;

  switch (i-3) {
   case 8: x = 5; break;
   case 3: x = 3; break;
   case 56: x = 12; break;
   case -3: x = 11; break;
   case 101: x = 4;break;
   default: x = -1;
  }
}

